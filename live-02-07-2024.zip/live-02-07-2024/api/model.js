const Models  = require('../database/models');

module.exports = { Models };