# server

npm install

touch .env

cat .env-sample >> .env

npm start